#if defined(REALTIME_API)

#include <Arduino.h>
#include <M5Unified.h>
#include <Avatar.h>
#include "share/Mutex.h"
//#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include "rootCA/rootCAgoogleGemini.h"
#include <ArduinoJson.h>
#include "SpiRamJsonDocument.h"
#include "GeminiLive.h"
#include "../ChatGPT/FunctionCall.h"    // GeminiとChatGPTのFunction Calling仕様は共通
//#include "MCPClient.h"
#include "Robot.h"

#include <base64.h>
#include "libb64/cdecode.h"
#include <WebSocketsClient.h>

using namespace m5avatar;
extern Avatar avatar;

static const char session_update[] =
        "{"
          "\"setup\": {"
            // ListModels で bidiGenerateContent 対応が確認できたモデルを指定する。
            // gemini-3.1-flash-live-preview はプレビュー版で無料枠がほぼ無く、
            // 接続直後に code=1011 "You exceeded your current quota" で切断されるため使わない。
            "\"model\": \"models/gemini-2.5-flash-native-audio-latest\","
#ifndef REALTIME_API_WITH_TTS
            // 【重要】ネイティブ音声モデルでは responseModalities を指定しないこと。
            //
            // "generationConfig": {"responseModalities": ["AUDIO"]} を入れていたところ、
            // 音声を送った瞬間に code=1007
            //   "The audio content type (CONTENT_TYPE_AUDIO) is not supported for this model configuration"
            // で切断される状態になった（実機で再現）。
            //
            // ネイティブ音声モデルは音声入出力が既定であり、responseModalities は
            // 「別途TTSを使う（テキストで受け取る）」場合にだけ指定するもの。
            // 指定してしまうと設定が音声非対応と解釈され、音声入力が拒否される。
            // 参考: LiveKit コミュニティで同じ 1007 エラーが報告され、
            //       modalities の指定を削除することで解決している。
            //       https://community.livekit.io/t/gemini-realtime-api-error-1007-none-the-audio-content-type-content-type-audio-is-not-supported-for-this-model-configuration/1737
#else
            "\"generationConfig\": {"
              "\"responseModalities\": [\"TEXT\"]"
              // TTS併用時のみテキスト出力を要求する
            "},"
#endif
            // 【重要・realtimeInputConfig は入れないこと（実機で2回失敗）】
            //
            // 失敗1: startOfSpeechSensitivity: START_SENSITIVITY_LOW を入れたところ、
            //   内蔵マイク＋通常の声量では発話開始が検知されず、turnComplete が一度も返らなくなった。
            //
            // 失敗2: 上記を外し endOfSpeechSensitivity と silenceDurationMs だけ残したところ、
            //   「1ターン目は成功するが、2ターン目以降が必ず無応答になる」状態になり、
            //   最終的に code=1007 "The audio content type (CONTENT_TYPE_AUDIO) is not supported
            //   for this model configuration" で切断された。
            //   automaticActivityDetection を部分指定すると、サーバ側が
            //   「自動検出を使わない＝クライアントが activityStart/End を送る」と解釈するためと思われる。
            //   （この設定を入れる前のログでは turnComplete が1セッションで3回出て複数ターン動いていた）
            //
            // → 自動VAD（既定）に任せる。騒音対策が必要になった場合は、部分指定ではなく
            //   automaticActivityDetection.disabled: true ＋ activityStart/activityEnd の
            //   送信実装をセットで行うこと。中途半端な指定が一番危険。
            // googleSearch は元のコードに入っており、複数ターン会話が成立していた頃の構成。
            // 展示の応答速度のために一度外したが、原因切り分けのため既知の動作状態に戻す。
            // 速度が問題なら、会話が安定してから改めて外して検証すること。
            "\"tools\": ["
              "{\"functionDeclarations\": []},"
              "{\"googleSearch\": {}}"
            "],"
            "\"systemInstruction\": {"
              "\"parts\": [{\"text\": \"You are an AI robot named Stack-chan. Please speak in Japanese.\"}],"
              "\"role\": \"user\""
            "}"
          "}"
        "}";

static const char input_audio_append[] =
        "{"
          "\"realtimeInput\": {"
            "\"audio\":{"
              "\"data\": \"REPLACE_TO_AUDIO_BASE64\","
              // 【重要】フィールド名は mimeType（キャメルケース）。
              // 元のコードは mime_type（スネークケース）だったが、Gemini Live API の
              // 公式仕様は mimeType。未知のフィールドは無視されるため、
              // サーバは音声の形式を判別できずエラーになる。
              // setup 側が responseModalities / systemInstruction とキャメルケースなのと同じ規則。
              // 公式: https://ai.google.dev/gemini-api/docs/live-api/get-started-websocket
              //
              // レートの明記も必須。RT_REC_SAMPLE_RATE(16000) と一致させること。
              "\"mimeType\": \"audio/pcm;rate=16000\""
            "}"
          "}"
        "}";

// for function calling
//
static const char function_response[] =
        "{"
            "\"tool_response\": {"
              "\"function_responses\": [{"
                "\"name\": \"REPLACE_TO_TOOL_NAME\","
                "\"response\": {\"result\":\"REPLACE_TO_OUTPUT\"},"
                "\"id\": \"REPLACE_TO_CALL_ID\""
              "}]"
            "}"
        "}";

// for debug (音声の代わりにテキストのプロンプトを入力する)
//
static const char input_text[] =
     "{"
        "\"client_content\": {"
          "\"turn_complete\": true,"
          "\"turns\": [{"
              "\"role\": \"user\","
              "\"parts\": ["
                  "{\"inline_data\": {\"mime_type\": \"text/plain\", \"data\": \"REPLACE_TO_TEXT_BASE64\"}}"
              "]"
          "}]"
        "}"
      "}";

// WebSocketのコールバック関数としてクラスメソッドを渡せないので、コールバック関数を
// 通常の関数にして静的変数を経由してクラスのthisポインタを渡す。
static GeminiLive* p_this;
static void webSocketEvent(WStype_t type, uint8_t * payload, size_t length) {
    String msgType, delta;
    DeserializationError error;

	switch(type) {
		case WStype_DISCONNECTED:
      {
      Serial.printf("[WSc] Disconnected!\n");

      // 会話の途中（AIが話している／こちらが話している）で切れたかどうか。
      // 待機中の切断は自動で再接続されるので、画面の「じゅんび中」で足りる。
      bool midTurn = p_this->speaking || p_this->isRealtimeRecording();

      // Gemini Liveは応答の音声が長くなると途中でDisconnectすることがあるため、ストリーミング再生の終了処理を行う。
      if(p_this->speaking == true){
        while (M5.Speaker.isPlaying()) { vTaskDelay(1); }
        M5.Speaker.end();
        M5.Mic.begin();
        exitMutexAudio();
        // 以前はここで録音を再開していたが、接続が切れているので送信は黙って捨てられ、
        // 利用者は「死んだ回線」に話しかけ続けることになる。録音は再開せずエラーを見せる。
        for(int i=0; i<RealtimeLLMBase::AUDIO_BUF_NUM; i++){
            memset(p_this->audioBuf[i], 0, 100 * 1024);
        }
        p_this->speaking = false;
      }
      if(p_this->isRealtimeRecording()){
        p_this->stopRealtimeRecord();
      }
      if(midTurn){
        Serial.println("[ERR] disconnected during conversation");
        p_this->showError(RealtimeLLMBase::ERR_DISCONNECTED);
      }
      }
      break;
		case WStype_CONNECTED:
			Serial.printf("[WSc] Connected to url: %s\n", payload);

            /*
             * JSON "setup"でAPIの振る舞いをカスタマイズする
             */
            {
                SpiRamJsonDocument sessionUpdateDoc(1024*10);
                DeserializationError error = deserializeJson(sessionUpdateDoc, session_update);
                if (error) {
                    Serial.println("webSocketEvent: JSON deserialization error (session_update)");
                }

                // instructionsにロール、前回会話の要約を設定
                //
                Serial.printf("role: %s\n", p_this->role.c_str());
                Serial.printf("sysRole: %s\n", p_this->systemRole.c_str());
                Serial.printf("userInfo: %s\n", p_this->userInfo.c_str());
                sessionUpdateDoc["setup"]["systemInstruction"]["parts"][0]["text"] = p_this->role;
                sessionUpdateDoc["setup"]["systemInstruction"]["parts"][1]["text"] = p_this->systemRole;
                sessionUpdateDoc["setup"]["systemInstruction"]["parts"][2]["text"] = p_this->userInfo;

                // MCP tools listをfunctionとして挿入
                //
                for(int s=0; s < p_this->param.llm_conf.nMcpServers; s++){
                    if(true == p_this->param.llm_conf.mcpServer[s].disabled){
                        continue;
                    }
                    if(!p_this->mcpClient[s]->isConnected()){
                        continue;
                    }

                    for(int t=0; t < p_this->mcpClient[s]->nTools; t++){
                        sessionUpdateDoc["setup"]["tools"][0]["functionDeclarations"].add(p_this->mcpClient[s]->toolsListDoc["result"]["tools"][t]);
                        if(!sessionUpdateDoc["setup"]["tools"][0]["functionDeclarations"][t]["parameters"]["additionalProperties"].isNull()){
                            // additionalPropertiesはGeminiで非対応のため削除する
                            sessionUpdateDoc["setup"]["tools"][0]["functionDeclarations"][t]["parameters"].remove("additionalProperties");
                        }
                    }
                }

                // FunctionCall.cppで定義したfunctionをsession.updateに挿入
                //
                SpiRamJsonDocument functionsDoc(1024*10);
                error = deserializeJson(functionsDoc, json_Functions.c_str());
                if (error) {
                    Serial.println("FunctionCall: JSON deserialization error");
                }

#if !defined(EXHIBITION_NO_FUNCTIONS)
                int nFuncs = functionsDoc.size();
                for(int i=0; i<nFuncs; i++){
                    sessionUpdateDoc["setup"]["tools"][0]["functionDeclarations"].add(functionsDoc[i]);
                }
#else
                // 【展示向け】関数(set_avatar_expression / update_memory)を登録しない。
                // 実機ログで、toolCall が発生した後のターンからモデルが音声を返さなくなり
                // （modelTurn without audio が連続）、最終的に
                // code=1007 "The audio content type (CONTENT_TYPE_AUDIO) is not supported
                // for this model configuration" で切断される現象を確認したため。
                // 1ターン目（toolCall前）は必ず成功し、2ターン目以降が無応答になるのが特徴。
                // 表情は RealtimeAiMod::idle() が会話状態から自前で制御しているので、
                // set_avatar_expression が無くても展示の見た目は変わらない。
                // 長期記憶(update_memory)も展示では使わない（キャラ設定で memory:false）。
                (void)functionsDoc;
                Serial.println("[WSc] functionDeclarations は登録しません（展示モード）");
#endif


                String sessionUpdateStr;
                serializeJson(sessionUpdateDoc, sessionUpdateStr);
                String jsonPretty;
                serializeJsonPretty(sessionUpdateDoc, jsonPretty);
                Serial.printf("[WSc] session update json: %s\n", jsonPretty.c_str());
                p_this->webSocket.sendTXT(sessionUpdateStr.c_str());
            }
			break;
		case WStype_TEXT:
			Serial.printf("[WSc] get text: %s\n", payload);
			//Serial.printf("[WSc] text size: %d\n", strlen((char*)payload));
			break;
		case WStype_BIN:
			// 音声チャンクごとに呼ばれるためSerial出力は行わない（再生が途切れる原因になる）
#if 0
			Serial.printf("[WSc] get binary length: %u\n", length);
#endif
			//p_this->hexdump(payload, length);
            //Serial.printf("[WSc] get binary: %s\n", payload);

            error = deserializeJson(p_this->msgDoc, payload);
            if (error) {
                Serial.printf("WebSocket Event: JSON deserialization error %d\n", error.code());
            }

            if(!p_this->msgDoc["setupComplete"].isNull()){
                Serial.printf("[WSc] setupComplete\n");
                //Serial.printf("[WSc] payload: %s\n", payload);
                avatar.setSpeechText("タッチしてね");

#if 0   // for debug (音声の代わりにテキストのプロンプトを入力する)
                String text_base64;
                text_base64 = base64::encode((u8*)"What time is it now ?", strlen("What time is it now ?"));
                String json(input_text);
                json.replace("REPLACE_TO_TEXT_BASE64", text_base64.c_str());
                Serial.printf("[WSc] input text for test: %s\n", json.c_str());
                p_this->webSocket.sendTXT(json);
#endif
            }
#ifndef REALTIME_API_WITH_TTS
            else if(!p_this->msgDoc["serverContent"]["modelTurn"]["parts"].isNull()){
                // 【重要】parts配列を全部走査して音声(inlineData)を探す。
                // 以前は parts[0] だけを見ており、しかも「parts[0]がtextなら何もしない」分岐が
                // else-if連鎖の手前にあったため、モデルが [0]=text, [1]=音声 の形で返すと
                // 音声が丸ごと捨てられていた（AIは返事しているのに端末は無音＝「返事が来ない」）。
                // 実機ログで modelTurn text が3回出て turnComplete が1回しか成立しない状態を確認。
                bool hasAudio = false;
                for(int pi = 0; pi < 8; pi++){
                    // ArduinoJson v7 のプロキシは auto でコピーできないため型を明示する
                    JsonVariantConst part = p_this->msgDoc["serverContent"]["modelTurn"]["parts"][pi];
                    if(part.isNull()){ break; }
                    if(part["inlineData"]["data"].isNull()){ continue; }

                    if(p_this->speaking == false){
                        Serial.printf("[WSc] input audio committed\n");
                        p_this->stopRealtimeRecord();
                        enterMutexAudio();
                        M5.Mic.end();
                        M5.Speaker.begin();
                        p_this->speaking = true;
                    }
                    delta = part["inlineData"]["data"].as<String>();
                    p_this->streamAudioDelta(delta);
                    hasAudio = true;
                }
                if(!hasAudio){
                    // 音声なしのターン。ここは受信処理の中なので重い処理を書かないこと。
                    // 一時的に serializeJson で中身をダンプしていたが、音声受信と競合するため削除した。
                    // 中身を見たいときだけ下を 1 にする。
#if 0
                    String dump;
                    serializeJson(p_this->msgDoc["serverContent"]["modelTurn"], dump);
                    Serial.printf("[WSc] modelTurn without audio: %s\n", dump.substring(0,300).c_str());
#else
                    Serial.printf("[WSc] modelTurn without audio\n");
#endif
                }
            }
#else
            else if(!p_this->msgDoc["serverContent"]["modelTurn"]["parts"][0]["text"].isNull()){
                Serial.printf("[WSc] modelTurn text\n");
            }
#endif
#ifndef REALTIME_API_WITH_TTS
            else if(false){    // 旧: parts[0]固定の音声処理（上の走査に統合済み）
            }
#else
            // TODO: Gemini Liveのメッセージ形式に変更（これはOpenAIの形式)
            #if 0
            else if(msgType.equals("response.output_text.delta")){
                p_this->outputText += msgDoc["delta"].as<String>();

                // 区切り文字を検出したらテキストをキューに追加
                int idx = p_this->search_delimiter(p_this->outputText);
                if(idx > 0){
                    String inputText = p_this->outputText.substring(0, idx);
                    Serial.printf("[WSc] Push text: %s\n", inputText.c_str());
                    p_this->outputTextQueue.push_back(inputText);
                    p_this->outputText = p_this->outputText.substring(idx + strlen("。"), p_this->outputText.length());
                }
            }
            #endif
#endif
            else if(!p_this->msgDoc["toolCall"]["functionCalls"][0].isNull()){
                Serial.printf("[WSc] toolCall: %s\n", payload);

                String name = p_this->msgDoc["toolCall"]["functionCalls"][0]["name"].as<String>();
                String args = p_this->msgDoc["toolCall"]["functionCalls"][0]["args"].as<String>();
                String call_id = p_this->msgDoc["toolCall"]["functionCalls"][0]["id"].as<String>();
                Serial.printf("name: %s, args: %s, id: %s\n", name.c_str(), args.c_str(), call_id.c_str());

                String response = p_this->fnCall->exec_calledFunc(name.c_str(), args.c_str());
                response.replace("\"", "\\\"");     //JSON内の文字列を囲む"にエスケープ(\)を付ける

                String json(function_response);
                json.replace("REPLACE_TO_TOOL_NAME", name.c_str());
                json.replace("REPLACE_TO_CALL_ID", call_id.c_str());
                json.replace("REPLACE_TO_OUTPUT", response.c_str());
                Serial.printf("[WSc] function output: %s\n", json.c_str());
                p_this->webSocket.sendTXT(json);
            }
            else if(!p_this->msgDoc["serverContent"]["turnComplete"].isNull()){
                Serial.printf("[T %lu] turnComplete\n", (unsigned long)millis());
                // 統計はリセットされるので、先に「音声が届いたか」を控えておく
                bool hadAudio = (p_this->audioChunkCount > 0) || p_this->speaking;
                p_this->reportAudioStats();     // 1発話ぶんの再生統計（途切れの実測）

#ifndef REALTIME_API_WITH_TTS
                if(!hadAudio){
                    // AIのターンが終わったのに、声が1つも届かなかった。
                    // 無料枠を使い切ったときに典型的に起きる（エラー文は出ないことが多い）。
                    // 録音を自動再開すると「きいてるよ」が出てエラーに気づけないので、
                    // 止めてエラーを見せる。利用者がタップすれば再挑戦できる。
                    Serial.println("[ERR] turn finished without audio (free-tier quota may be exhausted)");
                    p_this->stopRealtimeRecord();
                    p_this->showError(RealtimeLLMBase::ERR_NO_VOICE);
                }
                else {
                    while (M5.Speaker.isPlaying()) { vTaskDelay(1); }
                    M5.Speaker.end();
                    M5.Mic.begin();
                    exitMutexAudio();
                    p_this->startRealtimeRecord();

                    for(int i=0; i<RealtimeLLMBase::AUDIO_BUF_NUM; i++){
                        memset(p_this->audioBuf[i], 0, 100 * 1024);
                    }
                    p_this->speaking = false;
                }
#else
                p_this->response_done = true;
#endif
            }

            break;
		case WStype_ERROR:
		case WStype_FRAGMENT_TEXT_START:
		case WStype_FRAGMENT_BIN_START:
		case WStype_FRAGMENT:
		case WStype_FRAGMENT_FIN:
 			Serial.printf("[WSc] payload: %s\n", payload);		
            break;
        default:
			Serial.printf("[WSc] Unknown event\n");
            //Serial.printf("[WSc] payload: %s\n", payload);
            break;
	}

}


GeminiLive::GeminiLive(llm_param_t param) : RealtimeLLMBase(param)
{
  p_this = this;    //コールバック関数に静的変数経由でthisポインタを渡す
  msgDoc = SpiRamJsonDocument(1024*150);

  initMcpClientList(mcpClient, param.llm_conf.mcpServer, param.llm_conf.nMcpServers);
  fnCall = new FunctionCall(param, this, mcpClient);
  //fnCall->init_func_call_settings(robot->m_config);

  enableMemory(param.llm_conf.enableMemory);
  if(enableMemory()){
    Serial.println("Memory is enabled");
    M5.Lcd.println("Memory is enabled");
  }

  load_role();


  // WebSocket connect
  //
  avatar.setSpeechText("じゅんび中");
  // Google公式CAで署名・接続先名・有効期限を検証する（再接続時も同じ）。
  // 起動時のNTP同期が未完了なら期限検証で拒否され、同期後の再接続で復帰する。
  // 検証失敗時に beginSSL / setInsecure へ戻すとAPIキーが偽サイトに渡るため禁止。
  // APIキーは URLクエリ ?key= で渡す（Gemini Live WebSocket の公式認証方式）。
  // ヘッダ(x-goog-api-key)方式だと setup 直後にサーバ切断されるため。
  String wsUrl = "/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=" + param.api_key;
  webSocket.beginSslWithCA("generativelanguage.googleapis.com", 443, wsUrl.c_str(), root_ca_google_gemini);

  webSocket.onEvent(webSocketEvent);
  String auth = "x-goog-api-key: " + param.api_key;

  //webSocket.setAuthorization(auth.c_str());
  webSocket.setExtraHeaders(auth.c_str());

  // try ever 5000 again if connection has failed
  webSocket.setReconnectInterval(5000);

  // ハートビートを有効化する。
  // 未設定だと pingInterval=0 で ping を打たないため、テザリングの瞬断やNATタイムアウトで
  // TCPが半開き(half-open)になったとき isConnected() が true のまま張り付き、
  // 自動再接続が一生走らない「生きた死体」状態になる（展示で最も気づきにくい壊れ方）。
  // 15秒ごとにping / 3秒でpongが来なければ失敗 / 2回連続失敗で切断扱い→自動再接続。
  webSocket.enableHeartbeat(15000, 3000, 2);

}


void GeminiLive::load_role(){
  Serial.println("Load role from SPIFFS.");
  if(enableMemory()){
    systemRole = systemRole_memory;
  }else{
    systemRole = systemRole_noMemory;
  }
  systemRole += " " + systemRole_realtimeAvatarExpression;

  if(load_system_prompt_from_spiffs()){
    role = String((const char*)systemPrompt["messages"][SYSTEM_PROMPT_INDEX_USER_ROLE]["content"]);
    //Serial.printf("role length: %d\n", role.length());
    if (role == "") {
      Serial.println("SPIFFS user role is empty. set default role.");
      role = defaultRole;
    }

    userInfo = String((const char*)systemPrompt["messages"][SYSTEM_PROMPT_INDEX_USER_INFO]["content"]);
    //Serial.println(userInfo);
    int idx = userInfo.indexOf("User Info");
    if(idx < 0 || !enableMemory()){
      userInfo = "User Info: ";
    }
  }else{
    // load_system_prompt_from_spiffs()内でSPIFFSからの取得失敗かつ
    // デフォルトのシステムプロンプト設定に失敗した場合（通常起こり得ない）。
    role = defaultRole;
    userInfo = "User Info: ";
  }
}

String& GeminiLive::buildInputAudioJson(String& jsonBuf, String& base64)
{
    jsonBuf.concat(input_audio_append);
    jsonBuf.replace("REPLACE_TO_AUDIO_BASE64", base64);
    //Serial.println(jsonBuf);
    return jsonBuf;
}

#endif  //REALTIME_API
